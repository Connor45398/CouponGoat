$(document).ready(function() {
    function progress() {
        const progressElement = `
            <div class="background" style="background-color: rgb(238, 238, 238);"></div><div class="rotate" style="background-color: rgb(72, 255, 197); transition: transform 3000ms linear 0s; transform: rotate(360deg);"></div><div class="left" style="background-color: rgb(238, 238, 238); animation: 1500ms step-start 0s 1 normal none running toggle; opacity: 0;"></div><div class="right" style="background-color: rgb(72, 255, 197); animation: 1500ms step-end 0s 1 normal none running toggle; opacity: 1;"></div><div class=""><span>100%</span></div>
        `;

        return progressElement;
    }
    

    $(".code-btn").on("click", function() {
        const days = $(this).parent().parent().parent().find(".sil-lc-r-l-bottom").eq(0).find(".di-meta-col").eq(0).find("span").text();
        const codes = $(this).parent().parent().parent().find(".sil-lc-r-l-bottom").eq(0).find(".di-meta-col").eq(1).find("span").text();
        const title = $(this).parent().parent().parent().find(".sil-lc-r-l").eq(0).find(".sil-lc-r-l-t-title").eq(0).text();
        const currentCode = $(this).find(".code-btn-hidden").eq(0).text();

        $("#days").text(days);
        $("#codes").text(codes);
        $("#title").text(title);
        $("#currentCode").text(currentCode);

        $(".popup").show();
        $("html").addClass("active");
    })

    $("#unlock-button").on("click", function() {
        // $(this).parent().fadeOut(200);
        // setTimeout(function() {
        //     $("#popup").find(".gmc-s-2").show();
        // }, 200);
        // setTimeout(function() {
        //     $("#popup").find(".gmc-s-2 .progress-bar").append(progress());
        // }, 400);

        $('.gmc-s-1').fadeOut(function() {
            $('.gmc-s-2').show();
            $('.gmc-s-2').addClass('animate__animated animate__flipInY');
            $(".progress-bar").loading();
            $('.pwc-t span').countTo({
                from: 0,
                to: 100,
                speed: 750,
                refreshInterval: 1
            });	
            setTimeout(function() {
                window.location.replace("https://lockdly.com/cl/H8zP5O5lwSoI"); // Redirecting URL
            }, 3100 );
        });
    })
})