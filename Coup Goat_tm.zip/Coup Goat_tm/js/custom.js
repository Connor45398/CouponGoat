$.fn.loading = function () {
	var DEFAULTS = {
		backgroundColor: '#eee',
		progressColor: '#48ffc5',
		percent: 100,
		duration: 3000
	};	
	
	$(this).each(function () {
		var $target  = $(this);

		var opts = {
		backgroundColor: $target.data('color') ? $target.data('color').split(',')[0] : DEFAULTS.backgroundColor,
		progressColor: $target.data('color') ? $target.data('color').split(',')[1] : DEFAULTS.progressColor,
		percent: $target.data('percent') ? $target.data('percent') : DEFAULTS.percent,
		duration: $target.data('duration') ? $target.data('duration') : DEFAULTS.duration
		};
		// console.log(opts);

		$target.append('<div class="background"></div><div class="rotate"></div><div class="left"></div><div class="right"></div><div class=""><span>' + opts.percent + '%</span></div>');

		$target.find('.background').css('background-color', opts.backgroundColor);
		$target.find('.left').css('background-color', opts.backgroundColor);
		$target.find('.rotate').css('background-color', opts.progressColor);
		$target.find('.right').css('background-color', opts.progressColor);

		var $rotate = $target.find('.rotate');
		setTimeout(function () {	
			$rotate.css({
				'transition': 'transform ' + opts.duration + 'ms linear',
				'transform': 'rotate(' + opts.percent * 3.6 + 'deg)'
			});
		},1);		

		if (opts.percent > 50) {
			var animationRight = 'toggle ' + (opts.duration / opts.percent * 50) + 'ms step-end';
			var animationLeft = 'toggle ' + (opts.duration / opts.percent * 50) + 'ms step-start';  
			$target.find('.right').css({
				animation: animationRight,
				opacity: 1
			});
			$target.find('.left').css({
				animation: animationLeft,
				opacity: 0
			});
		} 
	});
}
$(window).on("scroll", function(){
    if ($(this).scrollTop() > 50) {
        $('.site-header').addClass('fixed');
    } else {
        $('.site-header').removeClass('fixed');
    }
});
$(document).ready(function() {
	
	var $cmsg = "Unlocking code...";
	
	
	$('#search-form').on('keyup keypress', function(e) {
		var keyCode = e.keyCode || e.which;
		if (keyCode === 13) { 
			e.preventDefault();
			return false;
		}
	});
	$("#search-input").keyup(function(){
        var search_input = $(this).val();
        $(".deals-item-col").each(function(){
            if ($(this).text().search(new RegExp(search_input, "i")) < 0) {
                $(this).fadeOut();
            } else {
                $(this).show();
            }
        });
    });
	var rme;
	$(document).on('click','.slr-t',function(){
		$s_d_icon = $(this).find(".sil-lr-img").attr('src');
		$_d_title = $(this).find(".sil-lc-r-l-t-title").text();
		$_d_meta = $(this).find(".di-meta-wrapper").html();
		$_d_code = $(this).find(".code-btn-hidden").html();
		rme = $(this).data('rurl');
		let r = Math.random().toString(36).substring(7);
		$('.sil-listing').append('<div id="'+r+'"></div>');
		// gS( "spwpff_1", function(src) {
		// 	$( '#'+r ).html(src).hide().fadeIn();
		// 	$.magnificPopup.open({
		// 		items: {
		// 			src: '.get-code-modal',
		// 		},
		// 		type: 'inline',
		// 		preloader: false,
		// 		mainClass: 'animated fadeIn',
		// 		modal: true,
		// 		fixedContentPos: true,
		// 		fixedBgPos: true,
		// 		callbacks: {
		// 			open: function() {							
		// 				$('.gcmc-title').text($_d_title);
		// 				$('.gcmc-meta').html($_d_meta);
		// 				$('.gcmc-code').html($_d_code);
		// 				$('.cmsg').html($cmsg);
		// 				$(document).on('click','.gfntbt',function(){
		// 					$('.gmc-s-1').fadeOut(function() {
		// 						$('.gmc-s-2').show();
		// 						$('.gmc-s-2').addClass('animate__animated animate__flipInY');
		// 						$(".progress-bar").loading();
		// 						$('.pwc-t span').countTo({
		// 							from: 0,
		// 							to: 100,
		// 							speed: 750,
		// 							refreshInterval: 1
		// 						});	
		// 						setTimeout(function() {
		// 							window.location.replace(rme);
		// 						}, 3100 );
		// 					});							
		// 				});	
		// 			}
		// 		}
		// 	});	
		// });
	});
	
	function aO(el, anim, onDone) {
		var $el = $(el);
		$el.addClass( 'animated ' + anim );
		$el.one( 'animationend', function() {
			$(this).removeClass( 'animated ' + anim );
			onDone && onDone();
		});
	}
	// function gS(step, onStep) {
    //     var xhr = new XMLHttpRequest();
    //     xhr.setRequestHeader("X-REQUESTED-WITH", 'xmlhttprequest');
    //     xhr.addEventListener('readystatechange', function() {
    //         if (xhr.readyState == 4) {
    //             onStep && onStep(xhr.responseText)
    //         }
    //     });
    //     xhr.send()
	// 	console.clear();
	// 	console.log("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    // }
});
